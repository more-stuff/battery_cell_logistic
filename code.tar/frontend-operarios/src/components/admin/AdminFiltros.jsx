import { estilos } from "../../styles/AdminConsulta.styles";

export const AdminFiltros = ({ filtros, onChange }) => {
  const cambiarEstado = (valor) => {
    onChange({
      target: {
        name: "is_defective",
        value: valor,
      },
    });
  };

  return (
    <div style={estilos.gridFiltros}>
      <div style={estilos.columnaGrid}>
        <label style={estilos.labelModern}>DMC Celda</label>
        <input
          name="dmc"
          value={filtros.dmc}
          onChange={onChange}
          style={estilos.inputModern}
          placeholder="Ej: A1-B2..."
        />
        <label style={estilos.labelModern}>HU Entrada (Proveedor)</label>
        <input
          name="hu_entrada"
          value={filtros.hu_entrada}
          onChange={onChange}
          style={estilos.inputModern}
          placeholder="Ej: SUP-123"
        />

        <label style={estilos.labelModern}>HU Salida / Caja ID</label>
        <input
          name="hu_salida"
          value={filtros.hu_salida}
          onChange={onChange}
          style={estilos.inputModern}
          placeholder="Ej: SIL-999"
        />

        <label style={estilos.labelModern}>ID temporal</label>
        <input
          name="id_temporal"
          value={filtros.id_temporal}
          onChange={onChange}
          style={estilos.inputModern}
          placeholder="Ej: TEMP-4953"
        />
      </div>

      <div style={estilos.columnaGrid}>
        <label style={estilos.labelModern}>Fecha Caducidad</label>
        <input
          type="date"
          name="fecha_caducidad"
          value={filtros.fecha_caducidad}
          onChange={onChange}
          style={estilos.inputModern}
        />
        <label style={estilos.labelModern}>Escaneado Desde</label>
        <input
          type="date"
          name="fecha_inicio"
          value={filtros.fecha_inicio}
          onChange={onChange}
          style={estilos.inputModern}
        />
        <label style={estilos.labelModern}>Escaneado Hasta</label>
        <input
          type="date"
          name="fecha_fin"
          value={filtros.fecha_fin}
          onChange={onChange}
          style={estilos.inputModern}
        />
        <label style={estilos.labelModern}>Puesto de escaneo</label>
        <input
          name="usuario_id"
          value={filtros.usuario_id}
          onChange={onChange}
          style={estilos.inputModern}
          placeholder="Ej: PUESTO 4"
        />
      </div>
      <div style={estilos.columnaGrid}>
        <label style={estilos.labelModern}>Estado / Calidad</label>
        <div style={estilos.buttonGroup}>
          {/* BOTÓN 1: TODOS */}
          <button
            type="button"
            onClick={() => cambiarEstado("")}
            style={{
              ...estilos.btnSegment,
              ...(filtros.is_defective === "" ? estilos.activeTodos : {}),
              borderRight: "1px solid #ccc",
            }}
          >
            📦 Todas
          </button>

          {/* BOTÓN 2: SOLO OK */}
          <button
            type="button"
            onClick={() => cambiarEstado("false")}
            style={{
              ...estilos.btnSegment,
              ...(filtros.is_defective === "false" ? estilos.activeOK : {}),
              borderRight: "1px solid #ccc",
            }}
          >
            ✅ Válidas
          </button>

          {/* BOTÓN 3: DEFECTUOSOS */}
          <button
            type="button"
            onClick={() => cambiarEstado("true")}
            style={{
              ...estilos.btnSegment,
              ...(filtros.is_defective === "true" ? estilos.activeNOK : {}),
            }}
          >
            ❌ Defectuosas
          </button>
        </div>
      </div>
    </div>
  );
};
